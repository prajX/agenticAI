import pandas as pd

def read_excel(file):
    df = pd.read_excel(file)
    testcases = {}
    for _, row in df.iterrows():
        name = row['TestCase']
        step = row['Step']
        testcases.setdefault(name, []).append(step)
    return testcases

def read_file(path):
    try:
        with open(path) as f:
            return f.read()
    except:
        return ""

def write_file(path, content, append=False):
    mode = "a" if append else "w"
    with open(path, mode) as f:
        f.write(content + "\n")
