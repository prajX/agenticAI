Base URL: https://jsonplaceholder.typicode.com
Auth: None
