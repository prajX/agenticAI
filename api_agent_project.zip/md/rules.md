Use pytest and requests.
Validate status codes.
Validate JSON fields.
Avoid hardcoding base URL.
