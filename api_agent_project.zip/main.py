from utils import *
import subprocess
import json

def build_prompt(steps, swagger_snippet, md_context):
    step_text = "\n".join([f"{i+1}. {s}" for i, s in enumerate(steps)])

    return f"""
You are an API test automation engineer.

Generate Python pytest code using requests.

{md_context}

API Contract:
{swagger_snippet}

Test Steps:
{step_text}

Output only Python code.
"""

def call_llm(prompt):
    # Replace with real API later
    return '''
import requests

def test_api():
    res = requests.get("https://jsonplaceholder.typicode.com/users/1")
    assert res.status_code == 200
    data = res.json()
    assert "name" in data
'''

def run_test():
    result = subprocess.run(["pytest", "generated/test_api.py"], capture_output=True, text=True)
    return result.returncode, result.stdout + result.stderr

def update_memory(error):
    summary = f"- Failure observed: {error[:200]}"
    write_file("md/memory.md", summary, append=True)

def update_compact():
    memory = read_file("md/memory.md")
    lines = memory.split("\n")[-5:]
    write_file("md/compact.md", "\n".join(lines), append=False)

def get_swagger_snippet():
    with open("swagger.json") as f:
        spec = json.load(f)
    return json.dumps(spec["paths"], indent=2)

testcases = {
    "GetUser": [
        "Call GET /users/1",
        "Validate status 200",
        "Validate response has name"
    ]
}

rules = read_file("md/rules.md")
memory = read_file("md/compact.md")
api_knowledge = read_file("md/api_knowledge.md")

md_context = f"Rules:\n{rules}\nMemory:\n{memory}\nAPI:\n{api_knowledge}"

swagger = get_swagger_snippet()

for name, steps in testcases.items():
    prompt = build_prompt(steps, swagger, md_context)
    code = call_llm(prompt)

    write_file("generated/test_api.py", code)

    rc, output = run_test()

    if rc != 0:
        print("Test failed. Updating memory...")
        update_memory(output)
        update_compact()
    else:
        print("Test passed")
